---
title: "README for lists for ICD-9 and ICD-10 comparison"
author: "Chris Stewart"
date: "April 2, 2018"
output: html_document
---

The lists mhrn_icd9_list_beta2 and mhrn_ICD10__list_beta4 were developed to understand trends over the October 2015 transition from ICD-9 AND ICD-10.  If continuity over a period spanning this date is desired, you may want to use these lists.

They differ from the "official"" ICD-9 and ICD-10 lists in that some classes have been expanded in order to reduce discrepancies between ICD-9 and ICD-10 or to understand the differences.  

Dementia is the main class affected by this step.  In ICD-10 these is less ability to distinguish between dementia due to known physiological causes and dementia referring only to behavioral symptoms.Therefore, the full spectrum of dementia and cognitive impairment codes outside of the F chapter are included.

Also, a few additional non-F codes were added then an code in the ICD-9 mental health range (290-319) was crosswalked to them.  The best example of this is R41.0 (disorientation) which was mapped from 298.9 (unspecified psychosis.)
